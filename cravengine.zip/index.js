const fs = require('fs');
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const multer = require('multer');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/cravengine', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected successfully'))
  .catch(err => console.error('MongoDB connection error:', err));

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// Mongoose schemas
const orderSchema = new mongoose.Schema({
    name: String,
    phone: String,
    email: String,
    address: String,
    items: Array,
    status: String
});

const foodItemSchema = new mongoose.Schema({
    name: String,
    email: String,
    type: String,
    price: Number,
    description: String,
    image: String // Store image path
});

const Order = mongoose.model('Order', orderSchema);
const FoodItem = mongoose.model('FoodItem', foodItemSchema);

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });

// Nodemailer transporter configuration
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'cravengine@gmail.com', // Replace with your email
        pass: 'sjphhloollvfofjx' // Replace with your Google App Password
    }
});

// Endpoint to place an order
app.post('/order', async (req, res) => {
    try {
        const order = new Order({ ...req.body, status: 'confirmed' });
        await order.save();

        // Generate formatted order details
        const orderDetails = req.body.items.map(
            (item) => `(${item.name} x ${item.quantity}): ₹${item.price * item.quantity}`
        ).join('\n');
        const totalAmount = req.body.items.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
        );

        // Send email confirmation
        const mailOptions = {
            from: 'cravengine@gmail.com',
            to: req.body.email,
            subject: 'Payment Successful - Order Confirmation',
            text: `
                Dear ${req.body.name},
                
                Thank you for your order!
                Here are your order details:

                ${orderDetails}

                Total Amount: ₹${totalAmount}

                We hope you enjoy your meal!
            `,
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Error sending order confirmation email:', error);
                return res
                    .status(500)
                    .send({ error: 'Failed to send confirmation email' });
            }
            console.log('Email sent:', info.response);
            res.send({ message: 'Order placed and email sent!' });
        });
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).send({ error: 'Failed to place order' });
    }
});

// Endpoint to add a food item

app.post('/order', async (req, res) => {
    try {
        const order = new Order({ ...req.body, status: 'confirmed' });
        await order.save();

        // Send email confirmation
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'cravengine@gmail.com',
                pass: 'klnhsjddsxevadfc'
            }
        });

        const mailOptions = {
            from: 'cravengine@gmail.com',
            to: req.body.email,
            subject: 'Order Confirmation',
            text: `Thank you for your order, ${req.body.name}!\n\nOrder Details:\n${JSON.stringify(req.body.items, null, 2)}\n\nTotal: ₹${req.body.items.reduce((sum, item) => sum + item.price * item.quantity, 0)}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return res.status(500).send({ error: 'Failed to send confirmation email' });
            }
            res.send({ message: 'Order placed and email sent!' });
        });
    } catch (error) {
        res.status(500).send({ error: 'Failed to place order' });
    }
});


// Endpoint to fetch orders
app.get('/orders', async (req, res) => {
    try {
        const orders = await Order.find({ status: 'confirmed' });
        res.json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).send({ error: 'Failed to fetch orders' });
    }
});

// Endpoint to update order status
app.put('/order/:id/status', async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const order = await Order.findByIdAndUpdate(id, { status }, { new: true });

        if (status === 'accepted') {
            // Notify customer
            const mailOptions = {
                from: 'cravengine@gmail.com',
                to: order.email,
                subject: 'Order Accepted',
                text: `Hello ${order.name},\n\nYour order has been accepted and is on its way!}`
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.error('Error sending order acceptance email:', error);
                    return res.status(500).send({ error: 'Failed to send acceptance email' });
                }
                console.log('Email sent:', info.response);
            });
        }
        res.send({ message: 'Order status updated successfully' });
    } catch (error) {
        console.error('Error updating order status:', error);
        res.status(500).send({ error: 'Failed to update order status' });
    }
});

// Endpoint to send OTP
app.post('/otp', (req, res) => {
    const otp = Math.floor(100000 + Math.random() * 900000); // Generate OTP
    const { email } = req.body;

    const mailOptions = {
        from: 'cravengine@gmail.com',
        to: email,
        subject: 'Your OTP',
        text: `Your OTP is ${otp}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending OTP email:', error);
            return res.status(500).send({ error: 'Failed to send OTP email' });
        }
        console.log('Email sent:', info.response);
        res.send({ otp });
    });
});

// Serve static files
app.use('/uploads', express.static('uploads'));
app.use(express.static('public'));

// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
