# Cravengine Project

## How to Run index.js

1. **Install Node.js and npm**:
   Download and install from [Node.js official website](https://nodejs.org/).

2. **Install Dependencies**:
   Open terminal in the project directory and run:"npm install express mongoose body-parser nodemailer multer"



to run the site use this command "node index.js" in terminal 